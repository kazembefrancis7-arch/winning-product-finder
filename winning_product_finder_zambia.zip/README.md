# Winning Product Finder

A single-file prototype for an AI-assisted Zambia-focused e-commerce product research dashboard.

## Run
Open `index.html` in a modern browser.

## Important
The included products and signal values are demonstration data. They are not live market measurements. To turn this into a production research system, connect the scoring layer to real data sources (search demand, social trends, marketplace listings, ad libraries, supplier prices, FX/shipping and local seller density) and replace the demo AI rationale with a server-side model/API.

## Core scoring concept
Opportunity = demand + problem solving + margin + momentum + audience + content potential, adjusted downward for competition and saturation.
